# Diseño Visual — Variantes por Nicho y Tono

## Paletas predefinidas por nicho

### Dental Premium (verde oscuro + cálido)
```css
--color-primary: #1A5C4B;
--color-accent: #C8956C;
--color-bg: #FDFBF7;
```
Tipografía: Playfair Display + DM Sans  
Tono: profesional, cercano, seguro

### Dental Moderno (azul marino + blanco)
```css
--color-primary: #1B3A6B;
--color-accent: #4A9FD4;
--color-bg: #F8FAFF;
```
Tipografía: Plus Jakarta Sans (peso 300/700) — sin serif  
Tono: tecnológico, limpio, moderno

### Estética / Belleza (dorado + crema)
```css
--color-primary: #8B6914;
--color-accent: #D4AF72;
--color-bg: #FEFCF8;
```
Tipografía: Cormorant Garamond + Nunito Sans  
Tono: lujo accesible, femenino, aspiracional

### Medicina Estética (negro + dorado)
```css
--color-primary: #1A1A1A;
--color-accent: #C9A84C;
--color-bg: #F9F7F4;
```
Tipografía: DM Serif Display + DM Sans  
Tono: premium, médico, exclusivo

### Ortodoncia Joven (morado + coral)
```css
--color-primary: #6B35B3;
--color-accent: #FF7B6B;
--color-bg: #FAFAFA;
```
Tipografía: Outfit (peso variable) — totalmente sans  
Tono: joven, energético, sin miedo

### Fisioterapia / Salud (verde agua + blanco)
```css
--color-primary: #2A8C7E;
--color-accent: #F4C06B;
--color-bg: #F6FFFE;
```
Tipografía: Sora + Inter  
Tono: recuperación, bienestar, confianza

---

## Tipografías recomendadas (Google Fonts)

### Combinaciones display + body

| Display (Headlines) | Body (Texto) | Carácter |
|---|---|---|
| Playfair Display | DM Sans | Clásico profesional |
| Cormorant Garamond | Nunito Sans | Lujo suave |
| DM Serif Display | DM Sans | Moderno editorial |
| Fraunces | Plus Jakarta Sans | Boutique / premium |
| Libre Baskerville | Source Sans 3 | Médico / académico |
| Outfit | Outfit | Todo sans, joven |
| Sora | DM Sans | Tech / moderno |

---

## Patrones de layout por sección

### Hero: variantes

**A) Split izquierda/derecha** (usado en la landing de referencia)
- Texto a la izquierda (60%) + Formulario flotante a la derecha (40%)
- Fondo: gradiente diagonal del color de fondo al primary-light + accent-light
- Elementos flotantes decorativos (floating badges de reseñas, "Sin espera", etc.)

**B) Hero centrado con imagen de fondo**
- Overlay semitransparente oscuro sobre foto de clínica
- Texto centrado blanco, H1 grande
- Formulario inline debajo del texto (fondo blanco, sombra)
- Indicado para: clínicas con fotos de instalaciones muy buenas

**C) Hero minimalista (solo texto + CTA)**
- Sin formulario en el hero — CTA va a sección dedicada abajo
- H1 muy grande (clamp 3rem → 5rem)
- Subtítulo corto
- Dos botones + trust indicators
- Indicado para: landing de branding, no de captura directa

### Stats: variantes

**Fila de 4** (default) → grid 4 columnas en desktop, 2 en móvil
**Grid 2x2** → más visual, con iconos grandes SVG
**Contador animado** → JS que cuenta desde 0 al cargar → mayor impacto

### Servicios: variantes

**Cards en grid 3 columnas** (default)
- Icono SVG + título + descripción + precio + CTA
- Hover: lift shadow + border color primary

**Cards tipo lista** (para muchos servicios)
- Layout en 2 columnas, cards horizontales con icono a la izquierda

**Tabs por categoría** (para clínicas con muchos servicios)
- Pestañas: Implantes / Ortodoncia / Estética / Preventiva / Urgencias
- Contenido cambia con JS

### Testimonios: variantes

**Slider autoplay** (default)
- Cards visibles: 1 en móvil, 2-3 en desktop
- Controles prev/next + dots paginación

**Grid estático 3 columnas** (para 3-5 testimonios)
- No slider, todo visible
- Más limpio, mejor para SEO

**Masonry** (para muchos testimonios)
- Variedad de alturas
- Moderno / editorial

---

## Elementos decorativos

### Fondos de sección
- **Sección "Why Us"**: fondo primario oscuro, texto blanco — contraste máximo
- **Sección alternada**: alternar `--color-bg` (cálido) con `--color-white`
- **Sección FAQ**: fondo muy sutil (primary-light al 30%)
- **CTA Final**: gradiente diagonal primary → primary-hover

### Separadores de sección
```css
/* Ola suave entre secciones */
.wave-divider {
  overflow: hidden;
  line-height: 0;
}
.wave-divider svg {
  display: block;
  width: 100%;
  height: 60px;
}
```

### Badges flotantes (Hero)
Pequeñas tarjetas blancas con sombra que flotan alrededor del formulario:
```
┌──────────────────┐
│ ⭐ 4.9 · 347 reseñas │
│ Google Verified  │
└──────────────────┘
```
Posición: `absolute`, una arriba-izquierda del card, otra abajo-derecha.

### Dot pulsante de "Disponible ahora"
```html
<span class="dot"></span>
```
```css
.dot {
  width: 8px; height: 8px;
  background: #4ADE80;
  border-radius: 50%;
  animation: pulse 2s infinite;
}
```

---

## Animaciones recomendadas

```css
/* Fade up — para cards y secciones */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Float — para el hero card */
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}

/* Pulse — para el dot "disponible" */
@keyframes pulse {
  0%, 100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.3); opacity: 0.7; }
}

/* Scale in — para modales y badges */
@keyframes scaleIn {
  from { opacity: 0; transform: scale(0.9); }
  to { opacity: 1; transform: scale(1); }
}
```

---

## Checklist de diseño

- [ ] ¿La paleta tiene suficiente contraste WCAG AA? (texto sobre fondo)
- [ ] ¿El CTA principal destaca claramente sobre todo lo demás?
- [ ] ¿Hay máximo 2-3 tamaños de fuente (H1, H2/H3, body)?
- [ ] ¿Los cards tienen hover state?
- [ ] ¿El formulario tiene estado focus visible?
- [ ] ¿El diseño funciona bien en 375px (iPhone SE)?
- [ ] ¿La sticky mobile CTA no oculta contenido importante?
- [ ] ¿Las imágenes tienen `loading="lazy"` excepto las above-the-fold?
- [ ] ¿El logo está en SVG inline o imagen optimizada?

---

## Integración con WordPress + Elementor Pro

### Tabla comparativa — HTML widget
Cuando el widget Table de Elementor no da el control necesario, usar **HTML widget** con este código base:

```html
<div class="comparison-wrap">
  <table class="comparison-table">
    <thead>
      <tr>
        <th>Característica</th>
        <th class="highlight">Esta clínica ✓</th>
        <th>Clínica de barrio</th>
        <th>Franquicia dental</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Especialista por área</td>
        <td class="highlight">✅ Siempre</td>
        <td>❌ Dentista general</td>
        <td>⚠️ A veces</td>
      </tr>
      <!-- más filas -->
    </tbody>
  </table>
</div>
```

CSS en Advanced → Custom CSS del HTML widget:
```css
selector .comparison-table { width: 100%; border-collapse: collapse; }
selector .comparison-table th, selector .comparison-table td { padding: 14px 16px; border: 1px solid #E5E0D8; text-align: center; }
selector .highlight { background: #E8F0ED; font-weight: 700; color: #1A5C4B; }
```

### Sticky Mobile CTA — Sección fija
Crear una sección nueva al final de la página:
- Section Settings → Layout → Stretch Section: ON
- Advanced → Custom CSS:
```css
selector { position: fixed; bottom: 0; left: 0; right: 0; z-index: 9999; background: #fff; box-shadow: 0 -4px 20px rgba(0,0,0,0.1); padding: 12px 20px; display: none; }
@media (max-width: 767px) { selector { display: flex !important; } }
```
- Contenido: 3 botones en columnas — Llamar (`tel:`), WhatsApp (`wa.me/`), Pedir cita (anchor al formulario)

### Floating badges en el Hero
Los badges decorativos alrededor del formulario se implementan con **Image Box** o **Text Editor** widget:
- Advanced → Positioning: Absolute
- Posición y desplazamiento manual (top/left/right/bottom)
- Solo visibles en desktop — ocultar en móvil (Advanced → Responsive → Hide on Mobile)

### Custom Code (Elementor Pro → Tools → Custom Code)
Para añadir JS global sin plugins adicionales:

```javascript
// Sticky nav shadow on scroll
window.addEventListener('scroll', () => {
  document.querySelector('.e-n-menu').classList.toggle('is-scrolled', window.scrollY > 60);
});
```

```css
/* En el <head> via Custom Code */
.is-scrolled { box-shadow: 0 2px 20px rgba(0,0,0,0.08) !important; }
```

