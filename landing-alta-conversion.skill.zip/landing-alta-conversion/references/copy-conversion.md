# Copy de Alta Conversión — Referencia por Sección

## Principios generales de copy para clínicas locales

1. **Hablar siempre al miedo, no al producto.** La gente no quiere "un implante de titanio". Quiere volver a comer sin dolor y no avergonzarse al sonreír.
2. **Ciudad en el copy = confianza local.** Repetir el nombre de la ciudad en headlines y subtítulos activa el SEO local Y la cercanía emocional.
3. **Prueba social antes de cualquier argumento.** Los números (8.500+ pacientes, 4.9★, 15 años) deben aparecer en las primeras pantallas.
4. **Reducir fricción, no añadir urgencia artificial.** En salud, la urgencia agresiva genera rechazo. Mejor: "Respuesta en menos de 2 horas."
5. **Especificidad > generalidad.** "Implantes con garantía de por vida" > "implantes de calidad". "Financiación real al 0%, sin comisión de apertura" > "facilidades de pago".

---

## HERO

### Fórmula del H1
```
[Resultado deseado] en [Ciudad] — [Diferenciador] + [Oferta]
```

**Ejemplos dental:**
- "La clínica dental de *Amposta* donde 8.500 vecinos ya sonríen sin miedo"
- "Tu dentista en *Tortosa* que sí atiende el mismo día. Sin listas de espera."
- "Implantes en *Tarragona* con garantía de por vida. Primera visita gratis."

**Ejemplos estética:**
- "El centro de estética en *Sabadell* donde los resultados hablan por sí solos"
- "Botox en *Barcelona* por médicos especialistas. Resultados naturales, sin riesgos."

### Subtítulo del Hero
Debe responder a: ¿Qué me llevaré exactamente si llamo ahora?
```
Pide tu [oferta gratuita]: incluye [elemento 1], [elemento 2] y [elemento 3]. Sin compromiso, sin esperas, sin letra pequeña.
```

### CTA principal
- "Reservar mi visita gratuita →"
- "Pedir cita ahora (respuesta en 2h)"
- "Quiero mi diagnóstico gratis"

### CTA secundario
- "Ver antes y después reales"
- "Hablar por WhatsApp"
- "Llamar ahora: 977 000 000"

### Trust indicators bajo el formulario
- ⭐ 4.9 en Google · 347 reseñas
- ✔ Sin compromiso
- 🔒 Tus datos están seguros (RGPD)

---

## TRUST BAR

Texto encima de los logos: "Como aparecemos en medios y plataformas de confianza:" o simplemente sin texto — los logos hablan solos.

---

## STATS / CIFRAS

Formato: número grande + etiqueta descriptiva. La etiqueta debe ser específica:
- "8.500+" → "Pacientes que confían en nosotros en Terres de l'Ebre"
- "15+" → "Años siendo el dentista de referencia en Amposta"
- "4.9★" → "Puntuación media en Google (347 reseñas verificadas)"
- "98%" → "Pacientes que vuelven y nos recomiendan"
- "24h" → "Tiempo máximo de respuesta a urgencias"

---

## SERVICIOS

### Headline de sección
"Todo lo que necesitas. Sin derivarte a otra clínica. Sin hacerte esperar semanas."

### Descripción de cada servicio (fórmula)
```
[Nombre del tratamiento]
[Frase de beneficio, no de característica]
→ Desde [precio] · [Dato de garantía o distintivo]
```

**Ejemplos:**
- **Implantes Dentales**: "Recupera todos tus dientes con implantes que duran toda la vida. Colocados por implantólogo especialista con más de 1.200 casos. Desde 1.200€ con financiación incluida."
- **Invisalign**: "Corrige tu mordida sin brackets. Sin molestias, sin que nadie lo note. Revisiones mensuales incluidas."
- **Blanqueamiento**: "Varios tonos más blanco en una sola sesión. Resultado inmediato y sin sensibilidad."

---

## PROCESO / 3 PASOS

### Headline
"De 'debería ir al dentista' a estar sentado en el sillón: solo 3 pasos."

### Los 3 pasos
1. **Pide cita** — "Llama, escríbenos por WhatsApp o rellena el formulario. Respuesta garantizada en menos de 2 horas."
2. **Ven a tu visita gratuita** — "Sin colas, sin esperas. Tu cita reservada a la hora exacta. Incluye diagnóstico y radiografía."
3. **Recibe tu plan personalizado** — "Te explicamos exactamente qué necesitas, cuánto cuesta y cómo financiarlo. Sin presión, sin sorpresas."

---

## POR QUÉ NOSOTROS (Why Us)

### Headline
"En [ciudad] hay varias clínicas dentales. Pero solo una tiene todo esto."

### Diferenciadores (elegir los más relevantes)
- ✅ Especialistas por área, no un dentista que hace de todo
- ✅ Tecnología de última generación: TAC 3D, escáner intraoral, láser
- ✅ Garantía escrita en implantes y trabajos protésicos
- ✅ Presupuesto cerrado antes de empezar — sin costes sorpresa
- ✅ Financiación real al 0% — aprobación en el mismo día
- ✅ Urgencias el mismo día: llamamos, vienes, te atendemos
- ✅ 15 años en el mismo sitio — somos de aquí, no una franquicia
- ✅ Seguimiento post-tratamiento incluido

**Truco**: Contrastar con lo que NO hacen las franquicias o clínicas de bajo coste.

---

## ANTES / DESPUÉS

### Headline
"No te lo contamos. Te lo enseñamos. Antes y después reales de pacientes de [ciudad]."

### Pie de cada caso
"[Nombre ficticio], [barrio/municipio cercano]. Tratamiento: [nombre]. Duración: [tiempo]."

### Nota legal (obligatoria)
"Todos los casos son pacientes reales que han dado su consentimiento. Los nombres son ficticios para proteger su privacidad."

---

## EQUIPO

### Headline
"Quién te va a tratar — porque tienes derecho a saber quién pone las manos en tu boca."

### Tarjeta de profesional (fórmula)
```
[Foto] | [Nombre completo]
[Especialidad]
[Universidad + año]
[1 dato humano/personal que genere conexión]
[Número de casos o años de experiencia]
```

---

## TABLA COMPARATIVA

### Headline
"¿Por qué elegirnos? Compara y decide."

| Característica | [Nombre Clínica] | Clínica de barrio | Franquicia dental |
|---|---|---|---|
| Especialista dedicado por área | ✅ Siempre | ❌ Un dentista general | ⚠️ A veces |
| Garantía escrita en implantes | ✅ De por vida | ❌ No | ⚠️ 2 años |
| Presupuesto cerrado y sin sorpresas | ✅ Siempre | ⚠️ Variable | ❌ Añaden extras |
| Financiación al 0% real | ✅ Hasta 24 meses | ❌ No ofrecen | ⚠️ Con comisiones |
| Urgencias el mismo día | ✅ Garantizado | ⚠️ Depende | ❌ Lista de espera |
| Años en la misma localización | ✅ 15 años | ⚠️ Variable | ❌ Cambian de local |

Columna propia: fondo primario, badge "La mejor opción".

---

## TESTIMONIOS

### Headline
"Lo que dicen quienes ya nos eligieron"

### Fórmula de cada testimonio
```
[5 estrellas ★★★★★]
"[Cita específica que menciona resultado concreto, NO genérica]"
— [Nombre], [Barrio/Ciudad] | Tratamiento: [nombre]
```

**Ejemplos buenos (específicos):**
- "Tenía terror al dentista desde hace 20 años. Aquí me trataron con una paciencia que no había encontrado en ningún otro sitio. Me hicieron 4 implantes sin sentir nada." — Marta R., Amposta
- "El precio me pareció justo, el presupuesto fue exacto al céntimo y en 6 meses tengo la sonrisa que siempre quise. Sin palabrería, sin ventas agresivas." — Jordi P., Sant Carles

**Ejemplos malos (evitar):**
- "Muy buena clínica, lo recomiendo" — sin nombre, sin especificidad → no convierte

---

## BANNER PROMO

Fondo con color primario o acento. Texto conciso:

```
[Oferta específica]
[Valor incluido]
[Urgencia suave: plazas limitadas / solo hasta fin de mes]
[CTA]
```

**Ejemplo:**
"Primera visita GRATUITA — Incluye: diagnóstico + exploración + Rx panorámica. Sin compromiso.
→ Reservar ahora (quedan X plazas esta semana)"

---

## FAQ

### Preguntas recomendadas (dental)
1. ¿La primera visita es realmente gratuita y sin compromiso?
2. ¿Cuánto cuestan los implantes en [ciudad]?
3. ¿Ofrecen financiación? ¿Cuáles son las condiciones?
4. ¿Atendéis urgencias el mismo día?
5. ¿Cuánto dura una ortodoncia invisible?
6. ¿Es doloroso colocarse implantes?
7. ¿Qué horario tenéis?

### Regla de copy en FAQ
Respuesta mínima: 2-3 frases. Nunca "sí" o "no" a solas. Cada respuesta debe reforzar un diferenciador o eliminar una objeción.

---

## UBICACIÓN

### Headline
"Nos encontrarás fácil — y si tienes dudas, te guiamos"

### Contenido del bloque
- Mapa embebido (Google Maps iframe) o imagen estática del mapa
- Dirección exacta con enlace a Google Maps
- Horario visual (tabla o lista días/horas)
- Indicaciones de cómo llegar: transporte público, parking cercano
- Teléfono + WhatsApp clicables

---

## CTA FINAL

### Headline
"El primer paso es fácil. Y es gratis."

### Cuerpo
"Pide tu visita gratuita hoy. Sin esperas, sin compromiso, sin sorpresas en el precio.
[Nombre de clínica] en [ciudad] — el equipo que lleva 15 años aquí."

### CTAs
- Botón primario: "Reservar mi visita gratuita"
- Botón secundario: icono WhatsApp + "Escribirnos por WhatsApp"

### Nota de urgencia (opcional, suave)
"Plazas limitadas por semana para visitas gratuitas. Asegura la tuya."

---

## STICKY MOBILE CTA

Siempre visible en móvil (posición fixed bottom):
```
[📞 Llamar] [💬 WhatsApp] [📅 Pedir cita]
```
Con fondo blanco, sombra superior, sin texto largo.

---

## Objeciones frecuentes y cómo destruirlas

| Objeción | Respuesta en copy |
|---|---|
| "El dentista me da miedo" | Sedación consciente disponible · equipo de trato humano · testimonios de pacientes con fobia |
| "Es caro" | Presupuesto cerrado · financiación al 0% · precio por tratamiento completo visible |
| "No sé si lo necesito" | Primera visita gratuita + diagnóstico escrito · sin compromiso |
| "Prefiero ir a mi dentista de siempre" | 15 años en la misma dirección · somos de aquí · conocemos a tus vecinos |
| "Tengo malas experiencias anteriores" | Tecnología sin dolor · anestesia tópica previa · tiempo de consulta sin prisas |
| "Las franquicias son más baratas" | Presupuesto cerrado vs. añaden extras · especialistas vs. dentista general · garantías escritas |
