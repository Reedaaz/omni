---
name: landing-alta-conversion
description: Genera landing pages de alta conversión para clínicas dentales, estéticas y negocios locales. Usa esta skill siempre que el usuario pida una landing page, página de captura, página de ventas, o cualquier página web diseñada para convertir visitas en leads o clientes. Incluye todas las secciones probadas en negocios locales: hero con formulario, barra de confianza, cifras, servicios, proceso, diferenciadores, antes/después, equipo, tabla comparativa, testimonios, promo, FAQ, ubicación, CTA final y footer. También úsala cuando el usuario pida adaptar o personalizar una landing existente para otra clínica o servicio.
---

# Landing Page de Alta Conversión

Skill para generar landings completas, visualmente profesionales y optimizadas para convertir — basadas en una estructura probada con clínicas dentales y estéticas en España.

## Flujo de trabajo

1. **Recopilar información del cliente** → Ver sección "Datos a recopilar"
2. **Elegir secciones** → Ver sección "Arquitectura de secciones"
3. **Aplicar principios de copy** → Ver `references/copy-conversion.md`
4. **Aplicar principios de diseño** → Ver `references/diseno-visual.md`
5. **Construir en Elementor Pro** → Sección por sección, revisando móvil en cada una
6. **Validar responsive completo** → Ver sección "Responsive en Elementor — Checklist por sección"

---

## ⚠️ Principio Mobile-First — OBLIGATORIO

**Más del 70% del tráfico a landings de clínicas locales llega desde móvil.** Esto no es una opción: toda sección, todo widget y todo elemento visual DEBE estar revisado y probado en móvil antes de dar la landing por terminada.

### Reglas inamovibles

- **Construir primero en desktop, validar inmediatamente en móvil.** Cada vez que se completa una sección en Elementor, cambiar al modo móvil (icono de teléfono en la barra inferior) y comprobar que se ve correctamente antes de pasar a la siguiente.
- **Nunca dejar el responsive para el final.** Acumular 17 secciones sin revisar el móvil genera el doble de trabajo de corrección.
- **Texto legible sin zoom.** Fuente mínima en móvil: 15px para cuerpo, 26px para H1. Revisar en Elementor → Mobile typography si es necesario sobreescribir.
- **Botones táctiles.** Altura mínima de cualquier botón o enlace: 44px. En Elementor: Button widget → Style → Padding mínimo 14px vertical.
- **Formulario usable con un dedo.** Campos con altura mínima 48px, bien separados, sin campos en 2 columnas en móvil.
- **Imágenes no desbordadas.** Ninguna imagen debe sobresalir del viewport. En Elementor: Image widget → Mobile → Width 100%.
- **Ningún elemento con posición absoluta visible en móvil** salvo que esté expresamente diseñado para ello. Los floating badges del hero se ocultan en móvil (Advanced → Responsive → Hide on Mobile).
- **Sticky Mobile CTA siempre visible.** Es el elemento de conversión más importante en móvil. Probar que no tapa contenido importante y que los botones son clicables.

### Flujo de revisión móvil en Elementor

```
Terminar sección en desktop
       ↓
Cambiar a modo Mobile (icono 📱 barra inferior)
       ↓
Revisar: texto, imágenes, columnas, botones, formulario
       ↓
Ajustar en Mobile view (los cambios solo afectan al móvil)
       ↓
Revisar también en Tablet (768px)
       ↓
Pasar a la siguiente sección
```

---

## Datos a recopilar antes de generar

Si el usuario no los proporciona, pregunta TODOS estos antes de empezar:

```
CLÍNICA / NEGOCIO
- Nombre de la clínica
- Ciudad y provincia
- Zona de influencia (barrios, municipios cercanos)
- Teléfono / WhatsApp
- Dirección física
- Horario
- URL del sitio (si existe)

OFERTA PRINCIPAL (Lead Magnet)
- ¿Qué se ofrece gratis o con descuento? (ej: "Primera visita gratis + diagnóstico + Rx")
- ¿Hay urgencias? ¿El mismo día?
- ¿Financiación? ¿Condiciones?

PRUEBA SOCIAL
- Número de pacientes / clientes
- Años de experiencia
- Puntuación Google y número de reseñas
- Certificaciones o galardones

SERVICIOS PRINCIPALES
- Lista de tratamientos o servicios (máx. 6 para la landing)
- Precio de referencia de los más importantes (opcional)

EQUIPO
- Nombres y especialidades de los dentistas / profesionales (1-3)
- Títulos o formación destacada

DIFERENCIADORES
- ¿Qué hace a esta clínica distinta? (tecnología, garantías, trato, ubicación...)

ESTILO VISUAL
- Colores corporativos (si los tienen)
- Tono de comunicación: ¿cercano/familiar o profesional/premium?
- ¿Tienen logo en SVG o texto?
```

---

## Arquitectura de secciones

Orden probado de máxima conversión. Cada sección tiene un rol específico en el embudo.

| # | Sección | Rol en el embudo | Siempre incluir |
|---|---------|-----------------|-----------------|
| 0 | **NAV sticky** | Acceso rápido + teléfono siempre visible | ✅ |
| 1 | **HERO** | Captar atención + formulario de captura | ✅ |
| 2 | **TRUST BAR** | Romper desconfianza inicial | ✅ |
| 3 | **STATS / CIFRAS** | Prueba social rápida | ✅ |
| 4 | **SERVICIOS** | Mostrar oferta completa | ✅ |
| 5 | **PROCESO 3 PASOS** | Reducir fricción de contacto | ✅ |
| 6 | **POR QUÉ NOSOTROS** | Diferenciación competitiva | ✅ |
| 7 | **ANTES / DESPUÉS** | Prueba visual de resultados | ⚠️ Si hay casos |
| 8 | **EQUIPO** | Humanizar + generar confianza | ✅ |
| 9 | **TABLA COMPARATIVA** | Destruir objeciones | ⚠️ Recomendado |
| 10 | **TESTIMONIOS** | Prueba social detallada | ✅ |
| 11 | **BANNER PROMO** | Urgencia + recordatorio de oferta | ✅ |
| 12 | **FAQ** | Resolver objeciones + SEO | ✅ |
| 13 | **UBICACIÓN** | Accesibilidad + horarios | ✅ |
| 14 | **CTA FINAL** | Último empujón a conversión | ✅ |
| 15 | **FOOTER** | Confianza legal + enlaces | ✅ |
| 16 | **STICKY MOBILE CTA** | Conversión en móvil | ✅ |

Para detalles de copy y diseño de cada sección → leer `references/copy-conversion.md`

---

## Stack técnico

- **WordPress** como CMS
- **Elementor Pro** como page builder — todas las secciones se construyen con widgets nativos de Elementor Pro
- **Google Fonts** disponibles directamente desde Elementor (Typography settings)
- **Schema.org**: plugin **Yoast SEO** o **Rank Math** para `LocalBusiness` (o `Dentist`) + `FAQPage`
- **Open Graph**: gestionado también por Yoast / Rank Math
- **Plugins recomendados**: ver sección "Plugins WordPress necesarios"

> ⚠️ Esta skill genera instrucciones y estructura — NO código HTML en bruto. Produce guías paso a paso para construir cada sección en Elementor Pro, con los widgets, settings y CSS personalizado necesarios.

---

## Paleta y tokens de diseño (Elementor Global Settings)

En Elementor Pro los tokens se definen en **Elementor → Site Settings → Global Colors & Fonts**. Estructura recomendada:

```
Global Colors:
  Primary       → #1A5C4B  (verde oscuro o el corporativo)
  Secondary     → #C8956C  (acento cálido)
  Text          → #1E1E1E
  Accent        → #E8F0ED  (primary light, para fondos de sección)

Global Fonts:
  Primary Font  → Playfair Display, Bold 700  (headlines / display)
  Secondary Font → DM Sans, Regular 400 / SemiBold 600  (cuerpo y UI)
```

Para CSS adicional (sombras, radios, colores secundarios) se añade en **Elementor → Site Settings → Custom CSS** o en **Apariencia → Personalizar → CSS adicional**:

```css
:root {
  --clr-bg: #FDFBF7;
  --clr-primary-hover: #134A3C;
  --clr-border: #E5E0D8;
  --clr-star: #F4A623;
  --shadow-card: 0 2px 12px rgba(0,0,0,0.06);
  --shadow-elevated: 0 12px 40px rgba(26,92,75,0.12);
  --radius: 12px;
  --radius-lg: 20px;
}
```

**Adaptar colores** si el cliente tiene identidad corporativa. Ver variantes por nicho en `references/diseno-visual.md`.

---

## Componentes críticos

### Formulario del Hero — Widget de Elementor Pro
El formulario es el elemento más importante. Usar **Form widget** de Elementor Pro:
- Máximo 4 campos: Nombre, Teléfono, Servicio (select), y opcionalmente Mensaje libre
- Botón con texto de acción ("Reservar mi visita gratuita") en color Global Primary
- Action After Submit: Email notification + integración (ver sección de integraciones)
- Disclaimer RGPD: campo tipo Acceptance ("He leído y acepto la política de privacidad")
- Floating badges decorativos: añadir con **Image Box** widget en posición absoluta (CSS personalizado en Advanced → Custom CSS del widget)

### Trust Bar — Widget Image Carousel o Image Box en fila
- **Image Carousel** de Elementor Pro con logos en escala de grises + hover color
- O bien fila de **Icon Box** widgets si los logos son SVG simples
- Fondo ligeramente diferenciado del hero (color blanco o gris muy suave)

### Stats / Cifras — Widget Counter
- Usar **Counter widget** de Elementor Pro para el número animado
- Layout: Inner Section con 4 columnas
- Añadir etiqueta descriptiva debajo con widget Text

### Tabla comparativa — Widget Table o HTML personalizado
- Elementor Pro no tiene widget de tabla nativa con el diseño requerido
- Usar **HTML widget** con la tabla en HTML + CSS inline o via Custom CSS del widget
- Ver `references/diseno-visual.md` para el HTML de la tabla

### Slider de testimonios — Widget Testimonial Carousel
- Usar **Testimonial Carousel** de Elementor Pro
- Mínimo 3 testimonios: foto, nombre, cargo (usar "Barrio · Tratamiento"), texto, estrellas
- Autoplay: activar en Settings del widget, interval 5000ms

### Before/After slider — Plugin externo
- Elementor Pro no incluye before/after nativo
- Usar plugin **WP Before After Image Slider** (gratuito) o **Smart Slider 3**
- Embeber con **Shortcode widget** de Elementor dentro de la sección

### FAQ Accordion — Widget Accordion o Toggle
- Usar **Accordion widget** de Elementor Pro
- Mínimo 5 preguntas. Las mismas que se añaden en Yoast/Rank Math como FAQPage schema
- Animación de apertura: configurar en Style tab del widget

---

## Plugins WordPress necesarios

| Plugin | Uso | Gratuito/Pro |
|---|---|---|
| **Elementor Pro** | Page builder principal | Pro |
| **Yoast SEO** o **Rank Math** | Meta, Schema LocalBusiness + FAQPage, OG | Gratuito (funciones básicas) |
| **WPForms** o **Fluent Forms** | Formularios si se necesita más control que el Form de Elementor | Gratuito/Pro |
| **WP Before After Image Slider** | Slider antes/después | Gratuito |
| **WP Rocket** o **LiteSpeed Cache** | Velocidad de carga | Pro / Gratuito |
| **Smush** o **ShortPixel** | Optimización de imágenes | Gratuito/Pro |
| **UpdraftPlus** | Backups | Gratuito |

---

## Integraciones del formulario (Action After Submit)

En el Form widget de Elementor Pro → Actions After Submit:

**Opción A — Solo email (básico)**
- Action: Email → configurar destinatario, asunto y campos del mensaje

**Opción B — Webhook a CRM/automatización**
- Action: Webhook → URL del webhook de Zapier, Make (Integromat) o n8n
- Desde ahí enrutar a cualquier CRM, Google Sheets, etc.

**Opción C — Integración directa con Mailchimp / ActiveCampaign**
- Elementor Pro tiene acciones nativas para ambos

```
Form widget → Actions After Submit:
  ✅ Email (notificación interna siempre)
  ✅ Webhook (para CRM)
  ✅ Redirect (página de gracias con píxel de conversión)
```

**Página de gracias** — crear página separada `/gracias` con:
- Mensaje de confirmación
- Píxel de conversión de Meta Ads (evento Lead) y/o Google Ads
- Añadir como Redirect en Actions After Submit

---

## SEO y meta (via Yoast SEO / Rank Math)

Configurar en el editor de la página → panel SEO:

```
Title: [Ciudad] | [Oferta principal] · [Nombre Clínica]
Meta description: [Prueba social]. [Servicios clave]. [Oferta]. [Teléfono]
```

- Schema `LocalBusiness` (o subtype `Dentist`): configurar en Rank Math → Local SEO o en Yoast → Schema tab
- Schema `FAQPage`: en Rank Math activar automáticamente desde el widget FAQ, o añadir manualmente en Yoast
- Open Graph: imagen destacada de la página como OG image (1200×630px)
- Canonical: Yoast/Rank Math lo gestiona automáticamente

---

## Animaciones y UX en Elementor

- **Entrance Animations**: cada sección o widget → Advanced → Motion Effects → Entrance Animation (Fade Up, recomendado)
- **Scroll Effects**: columnas del Hero → Advanced → Motion Effects → Scrolling Effects (sutil parallax)
- **Hover Effects en cards**: Style → Border → añadir box-shadow hover via Custom CSS del widget:
  ```css
  selector:hover { transform: translateY(-4px); box-shadow: 0 12px 40px rgba(26,92,75,0.12); transition: all 0.3s ease; }
  ```
- **Sticky Header**: Template de Header (Elementor Pro) → Settings → Sticky. Añadir clase `.scrolled` via JS en Custom Code si se quiere cambiar de estilo al hacer scroll.

---

## Responsive en Elementor — Checklist por sección

Breakpoints en **Elementor → Site Settings → Layout**:
- Mobile: ≤ 767px
- Tablet: 768px – 1024px
- Desktop: > 1024px

Revisar cada sección en los 3 breakpoints antes de pasar a la siguiente. Los ajustes hechos en vista Mobile solo afectan a móvil — no rompen el desktop.

---

### NAV (Header Template)
- [ ] Menú hamburger activado en móvil (Elementor Pro Header → Responsive → Breakpoint)
- [ ] Teléfono visible en el header móvil o dentro del menú desplegable
- [ ] Logo no cortado ni demasiado grande en 375px
- [ ] CTA del nav ("Pedir cita") visible o reemplazado por el menú hamburger

### HERO
- [ ] Columnas: de 2 columnas a 1 columna en móvil (Column → Mobile Width: 100%)
- [ ] Formulario debajo del texto (no al lado) en móvil
- [ ] H1: tamaño reducido en móvil (mínimo 26px, máximo 36px) — sobreescribir en Mobile Typography
- [ ] Floating badges ocultos en móvil (Advanced → Responsive → Hide on Mobile & Tablet)
- [ ] Fondo degradado visible y atractivo sin los elementos decorativos
- [ ] Botones del hero a ancho completo en móvil (Button → Mobile → Width: 100%)

### TRUST BAR
- [ ] Logos en fila scrollable horizontalmente O reorganizados en 2 filas en móvil
- [ ] Tamaño de logos adecuado (no demasiado pequeños ni demasiado grandes)
- [ ] Sin texto cortado debajo de cada logo

### STATS / CIFRAS
- [ ] De 4 columnas a 2 columnas en móvil (Section → Mobile Columns: 2)
- [ ] Número grande legible (mínimo 32px en móvil)
- [ ] Etiqueta descriptiva completa (no truncada)

### SERVICIOS
- [ ] Cards en 1 columna en móvil (de 3 desktop → 1 móvil)
- [ ] Icono + título + descripción bien alineados verticalmente
- [ ] CTA de cada card a ancho completo en móvil
- [ ] Sin overflow horizontal

### PROCESO / 3 PASOS
- [ ] Pasos apilados verticalmente en móvil (no en fila)
- [ ] Conector visual entre pasos (flecha o línea) adaptado a vertical o eliminado
- [ ] Numeración de cada paso claramente visible

### POR QUÉ NOSOTROS (Why Us)
- [ ] Texto blanco sobre fondo oscuro: contraste suficiente en móvil
- [ ] Lista de diferenciadores en 1 columna
- [ ] Iconos alineados correctamente con el texto

### ANTES / DESPUÉS
- [ ] Slider funcional en móvil con touch/swipe
- [ ] Handle del before/after arrastrable con el dedo
- [ ] Texto descriptivo de cada caso legible debajo de la imagen
- [ ] Imágenes no deformadas (object-fit: cover)

### EQUIPO
- [ ] Tarjetas de profesionales en 1 columna en móvil
- [ ] Foto + nombre + especialidad bien organizados
- [ ] Sin texto cortado en la bio

### TABLA COMPARATIVA
- [ ] Tabla scrollable horizontalmente en móvil (CSS: `overflow-x: auto` en el contenedor)
- [ ] O versión simplificada: solo 2 columnas en móvil ("Esta clínica" vs "El resto")
- [ ] Texto de celdas no demasiado pequeño (mínimo 13px)
- [ ] Columna destacada visible sin tener que hacer scroll

### TESTIMONIOS
- [ ] Carousel con swipe funcional en móvil
- [ ] 1 testimonio visible a la vez en móvil
- [ ] Foto de avatar, nombre y texto correctamente alineados
- [ ] Dots de paginación visibles y clicables (mínimo 20px de área táctil)

### BANNER PROMO
- [ ] Texto centrado en móvil, sin overflow
- [ ] CTA a ancho completo en móvil
- [ ] Fondo de color sin elementos decorativos que corten el texto

### FAQ ACCORDION
- [ ] Cada pregunta clicable con área táctil suficiente (mínimo 44px de alto)
- [ ] Texto de respuesta completo visible al expandir
- [ ] Sin saltos de layout al abrir/cerrar

### UBICACIÓN
- [ ] Mapa iframe a ancho completo en móvil (100% width)
- [ ] Horario en formato lista (no tabla) en móvil
- [ ] Dirección y teléfono como elementos separados y clicables

### CTA FINAL
- [ ] Headline reducido en móvil, sin texto en 2 líneas cortado raro
- [ ] Botones apilados verticalmente en móvil (no en fila)
- [ ] Espacio suficiente con el footer

### FOOTER
- [ ] Columnas del footer apiladas en móvil
- [ ] Enlaces con espacio suficiente entre ellos (no juntos)
- [ ] Logo centrado o alineado a la izquierda

### STICKY MOBILE CTA
- [ ] Visible únicamente en móvil (Hide on Desktop & Tablet)
- [ ] Fijo en la parte inferior, no se superpone con el contenido principal
- [ ] Los 3 botones (Llamar / WhatsApp / Pedir cita) claramente diferenciados
- [ ] Probado que el click en "Llamar" abre el marcador y "WhatsApp" abre la app

---

### Test final de móvil (antes de entregar)

Probar en estos entornos:
1. **Chrome DevTools** → Modo responsive → 375px (iPhone SE) y 390px (iPhone 14)
2. **Dispositivo físico real** — Android y iPhone si es posible
3. **PageSpeed Insights** (mobile) → Puntuación mínima recomendada: 70+ en móvil

```
https://pagespeed.web.dev/
```

Los problemas más frecuentes en móvil que hay que revisar expresamente:
- Texto demasiado pequeño (< 15px)
- Elementos demasiado juntos para hacer tap
- Imágenes que desbordan el ancho de pantalla
- Formulario con campos en 2 columnas (debe ser siempre 1 columna en móvil)
- Sticky mobile CTA que tapa el botón de envío del formulario

---

## Checklist antes de entregar

**Contenido**
- [ ] Todos los textos placeholder reemplazados con datos reales del cliente
- [ ] Imágenes del equipo, instalaciones y casos subidas a la Biblioteca de medios
- [ ] Teléfono clicable (`href="tel:+34XXXXXXXXX"`) en nav, hero y footer
- [ ] WhatsApp con mensaje predefinido (`https://wa.me/34XXXXXXXXX?text=Hola%2C+quiero+información`)

**Formulario y conversión**
- [ ] Form widget configurado con Actions: Email + Webhook/CRM + Redirect a página de gracias
- [ ] Página de gracias creada con píxel de conversión de Meta Ads y/o Google Ads
- [ ] Checkbox RGPD visible y obligatorio en el formulario
- [ ] Enlace a Política de Privacidad en el disclaimer del formulario

**SEO**
- [ ] Title y meta description configurados en Yoast/Rank Math
- [ ] Schema LocalBusiness con datos reales (teléfono, dirección, horario, rating)
- [ ] Schema FAQPage configurado con las preguntas del accordion
- [ ] OG Image (1200×630px) asignada como imagen destacada

**Velocidad y técnico**
- [ ] Imágenes optimizadas (WebP, <200KB cada una)
- [ ] Plugin de caché activo (WP Rocket o LiteSpeed)
- [ ] Fuentes de Google cargadas solo las necesarias (máx. 2 familias, máx. 3 pesos)
- [ ] Probado en móvil real (iPhone + Android) y en Chrome DevTools 375px
- [ ] Favicon subido en **Apariencia → Personalizar → Identidad del sitio**

---

## Referencias adicionales

Lee estos archivos cuando necesites profundizar en un área específica:

- `references/copy-conversion.md` → Fórmulas de copy para cada sección, headlines, CTAs, manejo de objeciones
- `references/diseno-visual.md` → Variantes de paleta, tipografías alternativas, patrones para distintos nichos (estética, ortodoncia, medicina, etc.)
